import React from 'react';
import '../App.css';

const Home = () => {
	return (
		<div>
			<p>
				This is  website where you can see some data of Marvel.
				<br/>
				If you want to BROWSE xxx, click xxx List.
				<br/>
				If you want to SEARCH xxx, click xxx Search.
			</p>
		</div>
	);
};

export default Home;
