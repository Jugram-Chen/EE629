import React from 'react';
import { Link } from 'react-router-dom';


const RNF = (props) => {
    return(<div>
        <h1>404 Resource no Found</h1>
        <br/>
        <Link to='/'>Back Home Page</Link>
    </div>)
};

export default RNF;
